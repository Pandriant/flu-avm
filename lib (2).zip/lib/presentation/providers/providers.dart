export './numerator_provider.dart';
export './modus_provider.dart';
export './bands_provider.dart';
export './charta_provider.dart';
export './pokemon_index_providers.dart';
export 'pokemon_provider.dart';